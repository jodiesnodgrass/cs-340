from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, USER, PASS, HOST, PORT, DB, COL): 
        # connection Variables 
        USER = 'aacuser' 
        PASS = 'Dixie1lynn' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        
        # initialize Connection using f-strings for cleaner string formatting
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}') 
        self.database = self.client[DB] 
        self.collection = self.database[COL] 

    def create(self, data):
        """ Inserts a document into the database and returns True if successful """
        if data is not None: 
            try:
                # capture the result of the insertion
                insert_result = self.collection.insert_one(data)
                
                # check if the insertion was acknowledged by the database and if an ID was actually generated/returned.
                if insert_result.acknowledged:
                    return True
                else:
                    return False
            except Exception as e:
                print(f"Error occurred during insertion of data: {e}")
                return False
        else: 
            raise ValueError("Nothing to save, because data parameter is empty") 

    def read(self, query):
        """ Queries the database and returns a list of matching documents """
        # if query is None or empty {}, it will return all documents
        # adjusted logic to allow empty dicts {} but catch None
        if query is not None:
            try:
                # Using self.collection (defined in __init__) for consistency
                documents = list(self.collection.find(query))
                return documents
            except Exception as e:
                print(f"Error occurred while reading data: {e}")
                return []
        else: 
            raise ValueError("Query parameter is None.")
            
    def update(self, query, update_data):
        """ Queries for and changes document(s) in the collection. Returns the number of documents modified. """
        if query is not None and update_data is not None:
            try:
                # update_many returns an UpdateResult object use the '$set' operator to ensure we only change specific fields
                # rather than replacing the entire document.
                result = self.collection.update_many(query, {"$set": update_data})
                
                # return the count of modified documents as requested
                return result.modified_count
            except Exception as e:
                print(f"Error occurred during update: {e}")
                return 0
        else:
            raise ValueError("Query and updated parameters are required")
            
    def delete(self, query):
        """ Queries for and removes document(s) from the collection. Returns the number of documents removed. """
        if query is not None:
            try:
                # delete_many removes all documents matching the query
                result = self.collection.delete_many(query)
                
                # return the count of deleted documents 
                return result.deleted_count
            except Exception as e:
                print(f"Error occurred while trying to delete: {e}")
                return 0
        else:
            raise ValueError("Query parameter is empty.")